import mindspore.dataset as ds
import csv
import numpy as np


def data_generator(file_path):
    with open(file_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            item_ids = np.array(list(map(int, row['item_ids'].split(','))), dtype=np.int32)
            behavior_ids = np.array(list(map(int, row['behavior_ids'].split(','))), dtype=np.int32)
            positions = np.array(list(map(int, row['positions'].split(','))), dtype=np.int32)
            label = np.array([int(row['label'])], dtype=np.int32)
            yield item_ids, behavior_ids, positions, label
def get_dataset(file_path, batch_size, num_shards, shard_id):
    ds_gen = ds.GeneratorDataset(data_generator(file_path), column_names=["item_ids", "behavior_ids", "positions", "labels"], num_shards=num_shards, shard_id=shard_id)
    ds_gen = ds_gen.batch(batch_size)
    return ds_gen
