import mindspore as ms
import mindspore.nn as nn
import mindspore.ops as ops
import mindspore.dataset as ds
from mindspore.communication.management import init, get_rank, get_group_size
from mindspore.train.callback import ModelCheckpoint, LossMonitor, TimeMonitor
from mindspore.train.serialization import save_checkpoint
from model import END4Rec, End4RecLoss
from dataset import get_dataset
from evaluation import evaluate
from distributed_utils import merge_checkpoints, allreduce_tensor
import json
import sys

ms.context.set_context(mode=ms.context.GRAPH_MODE, device_target="GPU")
init()
rank = get_rank()
group_size = get_group_size()
ms.context.set_auto_parallel_context(parallel_mode="data_parallel", device_num=group_size)

class TrainOneStepCell(nn.Cell):
    def __init__(self, network, optimizer):
        super(TrainOneStepCell, self).__init__(auto_prefix=False)
        self.network = network
        self.optimizer = optimizer
        self.grad = ops.GradOperation(get_by_list=True)
    def construct(self, *inputs):
        loss = self.network(*inputs)
        grads = self.grad(self.network, self.optimizer.parameters())(*inputs)
        self.optimizer(grads)
        return loss

def train_stage(model_loss, optimizer, dataset, stage_name, epochs):
    train_one_step = TrainOneStepCell(model_loss, optimizer)
    for epoch in range(epochs):
        epoch_loss = 0.0
        num_batches = 0
        for data in dataset.create_tuple_iterator():
            item_ids, behavior_ids, positions, labels = data
            loss = train_one_step(item_ids, behavior_ids, positions, labels)
            epoch_loss += loss.asnumpy()
            num_batches += 1
        print("Stage {} - Epoch {}, Loss: {}".format(stage_name, epoch+1, epoch_loss/num_batches))
def set_requires_grad(cell, requires_grad):
    for param in cell.get_parameters():
        param.requires_grad = requires_grad
def get_parameter_groups(model):
    group_emb_ebm = list(model.embedding.get_parameters()) + list(model.ebm.get_parameters())
    group_hard = list(model.hard_noise.get_parameters())
    group_soft = list(model.soft_noise.get_parameters())
    group_out = list(model.output_layer.get_parameters())
    return group_emb_ebm, group_hard, group_soft, group_out

def save_model_checkpoint(model, filename):
    ms.train.serialization.save_checkpoint(model, filename)

def train(config):
    pass
    # ckpt_cb = ModelCheckpoint(prefix="end4rec_rank{}".format(rank), directory="./ckpt/", save_checkpoint_steps=config["ckpt_steps"])
    # group_emb_ebm, group_hard, group_soft, group_out = get_parameter_groups(net)
    # set_requires_grad(net.embedding, True)
    # set_requires_grad(net.soft_noise, False)
    # set_requires_grad(net.output_layer, False)


    # num_items = config["num_items"]
    # num_behaviors = config["num_behaviors"]
    # seq_length = config["seq_length"]
    # d_model = config["d_model"]
    # num_blocks = config["num_blocks"]
    # epsilon = config["epsilon"]
    # batch_size = config["batch_size"]
    # data_file = config["data_file"]
    # net = END4Rec(num_items, num_behaviors, seq_length, d_model, num_blocks, epsilon)
    # loss_fn = nn.SoftmaxCrossEntropyWithLogits(sparse=True, reduction='mean')
    # net_loss = End4RecLoss(net, loss_fn, reg_weight=config["reg_weight"], contrast_weight=config["contrast_weight"])
    # ds_train = get_dataset(data_file, batch_size, group_size, rank)
    # ckpt_cb = ModelCheckpoint(prefix="end4rec_rank{}".format(rank), directory="./ckpt/", save_checkpoint_steps=config["ckpt_steps"])
    # group_emb_ebm, group_hard, group_soft, group_out = get_parameter_groups(net)
    # set_requires_grad(net.embedding, True)
    # set_requires_grad(net.ebm, True)
    # set_requires_grad(net.hard_noise, False)
    # set_requires_grad(net.soft_noise, False)
    # set_requires_grad(net.output_layer, False)
    # optimizer_stage1 = nn.Adam(net.embedding.get_parameters() + net.ebm.get_parameters(), learning_rate=config["learning_rate_stage1"])
    # train_stage(net_loss, optimizer_stage1, ds_train, "1", config["stage1_epochs"])
    # save_model_checkpoint(net, "./ckpt/ckpt_stage1_rank{}.ckpt".format(rank))
    # set_requires_grad(net.embedding, False)
    # set_requires_grad(net.ebm, False)
    # set_requires_grad(net.hard_noise, True)
    # set_requires_grad(net.soft_noise, False)
    # set_requires_grad(net.output_layer, False)
    # optimizer_stage2 = nn.Adam(net.hard_noise.get_parameters(), learning_rate=config["learning_rate_stage2"])
    # train_stage(net_loss, optimizer_stage2, ds_train, "2", config["stage2_epochs"])
    # save_model_checkpoint(net, "./ckpt/ckpt_stage2_rank{}.ckpt".format(rank))
    # set_requires_grad(net.embedding, False)
    # set_requires_grad(net.ebm, False)
    # set_requires_grad(net.hard_noise, False)
    # set_requires_grad(net.soft_noise, True)
    # set_requires_grad(net.output_layer, False)
    # optimizer_stage3 = nn.Adam(net.soft_noise.get_parameters(), learning_rate=config["learning_rate_stage3"])
    # train_stage(net_loss, optimizer_stage3, ds_train, "3", config["stage3_epochs"])
    # save_model_checkpoint(net, "./ckpt/ckpt_stage3_rank{}.ckpt".format(rank))
    # set_requires_grad(net.embedding, True)
    # set_requires_grad(net.ebm, True)
    # set_requires_grad(net.hard_noise, True)
    # set_requires_grad(net.soft_noise, True)
    # set_requires_grad(net.output_layer, True)
    # optimizer_stage4 = nn.Adam(net.get_parameters(), learning_rate=config["learning_rate_stage4"])
    # train_stage(net_loss, optimizer_stage4, ds_train, "4", config["stage4_epochs"])
    # save_model_checkpoint(net, "./ckpt/ckpt_stage4_rank{}.ckpt".format(rank))
    # from dataset import get_dataset
    # ds_eval = get_dataset(config["eval_data_file"], config["eval_batch_size"], group_size, rank)
    # hr, ndcg = evaluate(net, ds_eval, k=config["topk"])
    # print("Evaluation HR@{}: {}, NDCG@{}: {}".format(config["topk"], hr, config["topk"], ndcg))
    # if rank == 0:
    #     ckpt_paths = []
    #     for r in range(group_size):
    #         ckpt_paths.append("./ckpt/ckpt_stage4_rank{}.ckpt".format(r))
    #     merge_checkpoints(ckpt_paths, "./ckpt/merged_ckpt.ckpt")
