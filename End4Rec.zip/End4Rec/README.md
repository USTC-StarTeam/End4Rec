# **END4Rec: Efficient Noise-Decoupling for Multi-Behavior Sequential Recommendation**  

## **Overview**  
END4Rec is an **efficient noise-decoupling approach** designed for **multi-behavior sequential recommendation**. It introduces a **Noise-Decoupling Mechanism** to better model user interactions, **reduce noise interference**, and improve recommendation performance. The method is particularly useful for large-scale recommendation datasets such as **CIKM, IJCAI, and Taobao**.

## **Datasets**  
- **CIKM** ([Link](https://tianchi.aliyun.com/dataset/35680)): Contains multi-behavior user interactions (e.g., clicks, purchases) for sequential recommendation research.  
- **IJCAI** ([Link](https://tianchi.aliyun.com/dataset/42)): A real-world dataset from Taobao, incorporating various user-item interactions.  
- **Taobao** ([Link](https://tianchi.aliyun.com/dataset/649)): A large-scale e-commerce dataset covering user shopping behavior.  


The MindSpore implementation of END4Rec is optimized for parallel computation and efficient training, leveraging MindSpore’s automatic graph optimization and tensor acceleration to process large-scale recommendation data more efficiently. If you have any questions, please contact WeChat: 18331556501.
