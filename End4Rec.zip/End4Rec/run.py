import os
import numpy as np
import mindspore as ms
# from models import EBMRecModel
# from trainers import EBMRecTrainer
# from utils import EarlyStopping, get_local_time, get_rating_matrix
# from datasets import get_dataloader, get_seq_dic
from mindspore import context, Tensor, Model, nn, ops
from mindspore.common.initializer import Normal
from tqdm import tqdm
import argparse
import mindspore as ms
import mindspore.dataset as ds
import mindspore.nn as nn
from utils import dummy_data_generator, set_requires_grad, TrainOneStepCell
from model import END4Rec
from losses import End4RecLoss
from mindspore.communication.management import get_group_size, get_rank
from data_exp import load_data
from trainer import train_stage

# num_items = 1e8
# num_behaviors = 4
# seq_length = 50
# d_model = 128
# num_blocks = 4
# epsilon = 1e-3
# batch_size = 32
# total_samples = 1024

def a_try():
    pass
    # net = END4Rec(num_items, num_behaviors, seq_length, d_model, num_blocks, epsilon)
    # loss_fn = nn.SoftmaxCrossEntropyWithLogits(sparse=True, reduction='mean')
    # net_loss = End4RecLoss(net, loss_fn, reg_weight=0.01, contrast_weight=0.1)
    # data = load_data(name='cikm',chuck=100).from_online('tot').axg()
    # columns = ["item_ids", "behavior_ids", "positions", "labels"]
    # group_size = get_group_size()
    # shard_id = get_rank()
    # ds_train = ds.GeneratorDataset(data, column_names=columns, num_shards=group_size, shard_id=shard_id)
    # ds_train = ds_train.batch(batch_size)
    # set_requires_grad(net.embedding, True)
    # set_requires_grad(net.ebm, True)
    # set_requires_grad(net.hard_noise, False)
    # set_requires_grad(net.soft_noise, False)
    # set_requires_grad(net.output_layer, False)
    # optimizer_stage1 = nn.Adam(net.embedding.get_parameters() + net.ebm.get_parameters(), learning_rate=0.001)
    # # train_stage(net_loss, optimizer_stage1, ds_train, "1", 3)
    # set_requires_grad(net.embedding, False)
    # set_requires_grad(net.ebm, False)
    # set_requires_grad(net.hard_noise, True)
    # set_requires_grad(net.soft_noise, False)
    # set_requires_grad(net.output_layer, False)
    # optimizer_stage2 = nn.Adam(net.hard_noise.get_parameters(), learning_rate=0.001)
    # # train_stage(net_loss, optimizer_stage2, ds_train, "2", 2)
    # # set_requires_grad(net.embedding, False)
    # # set_requires_grad(net.ebm, False)
    # # set_requires_grad(net.hard_noise, False)
    # # set_requires_grad(net.soft_noise, True)
    # # set_requires_grad(net.output_layer, False)
    # # optimizer_stage3 = nn.Adam(net.soft_noise.get_parameters(), learning_rate=0.001)
    # # train_stage(net_loss, optimizer_stage2, ds_train, "3", 2)
    # set_requires_grad(net.embedding, True)
    # set_requires_grad(net.ebm, True)
    # set_requires_grad(net.hard_noise, True)
    # set_requires_grad(net.soft_noise, True)
    # set_requires_grad(net.output_layer, True)
    # optimizer_stage4 = nn.Adam(net.get_parameters(), learning_rate=0.0005)
    # print("Stage 4: Joint fine-tuning")
    # train_stage(net_loss, optimizer_stage4, ds_train, "4", 3)


