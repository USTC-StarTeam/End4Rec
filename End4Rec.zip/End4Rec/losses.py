# class End4RecLoss(nn.Cell):

#     def __init__(self, model, loss_fn, reg_weight=0.01, contrast_weight=0.1):
#         super(End4RecLoss, self).__init__()
#         self.model = model
#         self.loss_fn = loss_fn
#         self.reg_weight = reg_weight
#         self.contrast_weight = contrast_weight
#         self.contrast_loss_fn = ContrastiveLossCell()

#     def construct(self, item_ids, behavior_ids, positions, labels, neg_ids):
#         logits, reg_loss, S, S_hp, S_hn, S_sp, S_sn = self.model(item_ids, behavior_ids, positions)
#         pos_ids = item_ids  
#         neg_ids = neg_ids  
#         seq_out = logits  
#         pred_loss = self.cross_entropy(seq_out, pos_ids, neg_ids)

#         contrast_loss_hard = self.contrast_loss_fn(S_hp, S, S_hn)
#         contrast_loss_soft = self.contrast_loss_fn(S_sp, S_hp, S_sn)
        
#         total_loss = pred_loss + self.reg_weight * reg_loss + self.contrast_weight * (contrast_loss_hard + contrast_loss_soft)
        
#         return total_loss

#     def cross_entropy(self, seq_out, pos_ids, neg_ids):
#         pos_emb = self.model.item_embeddings(pos_ids)
#         neg_emb = self.model.item_embeddings(neg_ids)

#         seq_emb = seq_out[:, -1, :] 

#         pos_logits = torch.sum(pos_emb * seq_emb, -1) 
#         neg_logits = torch.sum(neg_emb * seq_emb, -1)  

#         loss = torch.mean(
#             - torch.log(torch.sigmoid(pos_logits) + 1e-24) -
#             torch.log(1 - torch.sigmoid(neg_logits) + 1e-24)
#         )

#         return loss
